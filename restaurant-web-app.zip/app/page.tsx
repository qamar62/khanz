import { Navbar, Footer, FloatingCTA } from "@/components/layout";
import {
  HeroSection,
  AboutPreview,
  SignatureDishes,
  CateringSection,
  TestimonialsSection,
  GalleryPreview,
  ReservationBanner,
  InstagramSection,
} from "@/components/home";

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main>
        <HeroSection />
        <AboutPreview />
        <SignatureDishes />
        <CateringSection />
        <TestimonialsSection />
        <GalleryPreview />
        <ReservationBanner />
        <InstagramSection />
      </main>
      <Footer />
      <FloatingCTA />
    </>
  );
}
